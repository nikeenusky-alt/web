/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Power, Settings, Zap, History, Info, Sun } from 'lucide-react';

export default function App() {
  const [isOn, setIsOn] = useState(false);
  const [intensity, setIntensity] = useState(1);
  const [strobeActive, setStrobeActive] = useState(false);
  const [strobeFreq, setStrobeFreq] = useState(10);
  const [hasFlash, setHasFlash] = useState(false);
  const trackRef = useRef<MediaStreamTrack | null>(null);

  // Initialize hardware torch
  useEffect(() => {
    async function initTorch() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        const track = stream.getVideoTracks()[0];
        const capabilities = track.getCapabilities() as any;
        
        if (capabilities.torch) {
          trackRef.current = track;
          setHasFlash(true);
        }
      } catch (err) {
        console.warn('Flash hardware not accessible:', err);
      }
    }
    // We only try to init if user interacts or we can check permissions?
    // ActuallygetUserMedia might pop a permission dialog immediately.
    // Let's do it on mounting.
    initTorch();

    return () => {
      if (trackRef.current) {
        trackRef.current.stop();
      }
    };
  }, []);

  // Control hardware torch
  useEffect(() => {
    if (trackRef.current && hasFlash) {
      trackRef.current.applyConstraints({
        advanced: [{ torch: isOn }]
      } as any).catch(err => {
        console.error('Failed to toggle torch:', err);
      });
    }
  }, [isOn, hasFlash]);

  // Strobe effect logic
  useEffect(() => {
    let interval: number;
    if (strobeActive && isOn) {
      interval = window.setInterval(() => {
        setIsOn(prev => !prev);
      }, 1000 / strobeFreq);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [strobeActive, strobeFreq, isOn]);

  const toggleTorch = () => {
    setIsOn(!isOn);
    if (strobeActive) setStrobeActive(false);
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4">
      {/* Device Frame */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-[360px] h-[680px] frosted-glass rounded-[50px] shadow-2xl flex flex-col p-6 z-10 overflow-hidden"
      >
        <div className="glow-overlay" />
        
        {/* Status Bar Mock */}
        <div className="flex justify-between items-center px-3 mb-10 text-[12px] opacity-60 font-medium">
          <span>9:41 AM</span>
          <div className="flex items-center gap-1">
            <span>100%</span>
            <span className="text-[10px]">🔋</span>
          </div>
        </div>

        {/* Light Beam Effect */}
        <div className={`light-beam transition-opacity duration-1000 ${isOn ? 'active' : 'opacity-0'}`} />

        {/* App Title */}
        <div className="text-center mb-12">
          <h1 className="text-2xl font-light tracking-[0.2em] text-white/90">LUMINA PRO</h1>
          <p className="text-[10px] font-mono text-white/30 tracking-widest uppercase mt-2">
            {hasFlash ? 'HARDWARE SYNC' : 'SIMULATION MODE'}
          </p>
        </div>

        {/* Power Section */}
        <div className="flex flex-col items-center gap-6 mb-10">
          <div className="power-ring">
            <motion.button
              onClick={toggleTorch}
              whileTap={{ scale: 0.9 }}
              animate={{ 
                scale: isOn ? 1.05 : 1,
              }}
              className={`w-[140px] h-[140px] rounded-full flex items-center justify-center transition-all duration-500 ${
                isOn ? 'power-btn-glow text-black' : 'bg-white/5 text-white/40 border border-white/5'
              }`}
            >
              <Power size={48} strokeWidth={1.5} />
            </motion.button>
          </div>
          
          <motion.div 
            animate={{ opacity: isOn ? 1 : 0 }}
            className="beam-indicator text-[12px] font-bold tracking-[0.3em] text-[#ffb000]"
          >
            BEAM ACTIVE
          </motion.div>
        </div>

        {/* Intensity Control Card */}
        <div className="frosted-glass rounded-[24px] p-5 mb-4 border-white/10">
          <div className="flex justify-between items-center text-[10px] font-bold tracking-widest uppercase mb-4 opacity-80">
            <span>Intensity</span>
            <span className="text-[#ffb000]">{Math.round(intensity * 100)}%</span>
          </div>
          <div className="relative h-1 bg-white/10 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-white" 
              animate={{ width: `${intensity * 100}%` }}
              transition={{ type: "spring", stiffness: 100, damping: 20 }}
            />
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.01"
              value={intensity}
              onChange={(e) => setIntensity(parseFloat(e.target.value))}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          </div>
        </div>

        {/* Mode Grid */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          <motion.button
            onClick={() => setStrobeActive(!strobeActive)}
            whileTap={{ scale: 0.95 }}
            className={`flex flex-col items-center justify-center gap-2 h-[60px] rounded-[16px] transition-all duration-300 border ${
              strobeActive ? 'bg-white/15 border-white/30 opacity-100' : 'bg-white/5 border-white/5 opacity-70'
            }`}
          >
            <Zap size={16} className={strobeActive ? 'text-white' : 'text-white/60'} />
            <span className="text-[9px] font-bold tracking-widest uppercase">Strobe</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            className={`flex flex-col items-center justify-center gap-2 h-[60px] rounded-[16px] transition-all duration-300 border ${
              !strobeActive ? 'bg-white/15 border-white/30 opacity-100' : 'bg-white/5 border-white/5 opacity-70'
            }`}
          >
             <Sun size={16} className="text-white/60" />
            <span className="text-[9px] font-bold tracking-widest uppercase">Normal</span>
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            className="flex flex-col items-center justify-center gap-2 h-[60px] rounded-[16px] bg-white/5 border border-white/5 opacity-70 hover:opacity-100"
          >
            <History size={16} className="text-white/60" />
            <span className="text-[9px] font-bold tracking-widest uppercase">SOS</span>
          </motion.button>
        </div>

        {/* Battery Info / Footer */}
        <div className="mt-auto flex justify-between items-center text-[12px] opacity-40 font-medium">
          <span>Est. Runtime</span>
          <span>4h 20m</span>
        </div>
      </motion.div>
    </div>
  );
}
